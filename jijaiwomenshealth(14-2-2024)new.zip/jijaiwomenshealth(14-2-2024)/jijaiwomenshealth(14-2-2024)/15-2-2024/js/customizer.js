 // prettyPhoto
  $("a[rel^='prettyPhoto[gallery1]']").prettyPhoto(); 
  $("a[rel^='prettyPhoto[iframes]']").prettyPhoto(); 
  $("a[rel^='prettyPhoto']").prettyPhoto(); 

 
  